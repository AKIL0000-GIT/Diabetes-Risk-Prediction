# diabetes-risk-prediction
Diabetes Risk Prediction — A machine learning project using genetic and health data to predict diabetes risk. Built with Streamlit and Jupyter Notebook, featuring model training, visualization, and interactive predictions.
